angular.module('starter.controllers')
	
	
.controller('JobHistoryCtrl', function($scope, $rootScope, $timeout, $state, $localstorage, $http, $window, database, Utils, applicationServices, $ionicScrollDelegate) {

	$scope.$parent.$parent.$parent.app_page_title = 'Job History';
	$scope.$parent.$parent.$parent.showBackButton = 'showBackButton';
	$scope.$parent.$parent.$parent.showLogo = '';
	$scope.$parent.$parent.$parent.showTodayTaskIcon = false;	
	$rootScope.setupHttpAuthHeader();
	$scope.custRecords = ''
	
	$scope.noTicketFlag = false;
	$localstorage.setWithOutEncryption('CUST-SYS-ID', '');
	$localstorage.setWithOutEncryption('PARTIAL_TICKET_DATA','');
	
	

//$scope.$parent.searchFilter = 'z';
	
$scope.backToTicketsListing = function() {
		if ($scope.openTicketCheckPhone()) {
			$state.go('eventmenu.myopenticketphone');
		} else {
			$state.go('eventmenu.home');
		}
	};



try {
Utils.showPleaseWait(pleaseWait);
			database.getCustInfoData(function(result) {
				//console.log(result.rows.length);
			$scope.custValue = [];
			
				if (result && result.rows.length > 0) {
					try {
						//console.log(result.rows.length)
						for (var i = 0; i < result.rows.length; i++) {
							var cName = '';
								var cSys  = '';
							//console.log(i);
							//console.log(angular.fromJson(result.rows.item(i).Data))
							var applicationAccess = result.rows.item(i);
							//console.log(angular.fromJson(applicationAccess.Data))
							var data = (angular.fromJson(applicationAccess.Data));
							for(var j=0;j<19;j++){
								//console.log(j);
								if(data[j].field_name == 'name'){
									cName = data[j].field_value;
									
								} else if(data[j].field_name == 'sys_id'){
									cSys = data[j].field_value;
								}
								
								if(cName && cSys){
									$scope.custValue.push({'custName':cName,'custSys':cSys});
									cName = '';
									cSys  = '';
								}
								
							}
						}
					} catch(e) {
						Utils.hidePleaseWait();
					}
					//Utils.hidePleaseWait();
		}				
				
				
			
			console.log($scope.custValue);
			Utils.hidePleaseWait();
			});
		} catch(e) {
			Utils.hidePleaseWait();
		}


$scope.selectCustomer = function(data){


console.log(data.custSys)
	$scope.showData = true;	
Utils.showPleaseWait(pleaseWait);
$http.get($rootScope.baseAppURL+'/api/inmpl/inm_mobile_application/inm_app_workreq_task?req_type=history&req_customer='+data.custSys).success(function(data, status, headers, config) {
			if (data && status == 200 && data.result && data.result.length > 0) {					
				$scope.custRecords = data.result;
				Utils.hidePleaseWait();
				$scope.noTicketFlag = true;
			} else {
				Utils.hidePleaseWait();
				$scope.custRecords = ''
				$scope.noTicketFlag = true;
			}
		}).error(function(data, status, headers, config) {
			//console.log(data.error.message)
			Utils.hidePleaseWait();
			$scope.custRecords = ''
			$scope.noTicketFlag = true;
		});


}

$scope.showDetails = function(data){
		$localstorage.set('SELECTED_ACCOUNT', angular.toJson(data));		
		$state.go('eventmenu.visitdetailsedit');	
}


})
