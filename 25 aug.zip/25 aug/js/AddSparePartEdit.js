angular.module('starter.controllers').controller('AddSparePartEditCtrl', function($scope, $rootScope, $timeout, $state, $localstorage, $http, $window, database, Utils, applicationServices, $ionicPopup, $parse, $ionicScrollDelegate) {

	$scope.$parent.$parent.$parent.app_page_title = 'Add Spare Part Edit';
	$scope.$parent.$parent.$parent.showBackButton = 'showBackButton';
	$scope.$parent.$parent.$parent.showLogo = '';
	$scope.$parent.$parent.$parent.showTodayTaskIcon = false;
	$rootScope.setupHttpAuthHeader();

	var now = new Date();
	var tzoffset = (now).getTimezoneOffset() * 60000;
	//offset in milliseconds
	var todayDate = (new Date(Date.now() - tzoffset)).toISOString().slice(0, 10);
	$scope.formData = {}

	$scope.show_section = {};

	// Accordion Display
	$scope.section_click = function(section, $event) {
		$scope[section] = !$scope[section];
		$ionicScrollDelegate.resize();
	};

	$scope.openTicketCheckPhone = function() {
		if ($('#openTicketCheckPhone').is(':hidden')) {
			return false;
		} else {
			return true;
		}
	};

	$scope.backToTicketsListing = function() {
		if ($scope.openTicketCheckPhone()) {
			//$state.go('eventmenu.myopenticketphone');
			$state.go('eventmenu.home');
		} else {
			$state.go('eventmenu.home');
		}
	};

	// Get the selected record from local storage
	var selectedItem = $localstorage.get('SELECTED_SPARE');
	$scope.records = angular.fromJson(selectedItem);
	//console.log($scope.records)

	var selectedCustInfo = $localstorage.getWithOutEncryption('CUST-SYS-ID');

	console.log($scope.records)

	// Create Contract Line data based on header sys id

	//console.log('sys ='+ recordSys)

	$scope.openFirstAccordion = function() {
		$timeout(function() {
			$scope.accordName = [];
			for (var i = 0; i < 1; i++) {
				if ($scope.records[i].field_type == 'acc_start') {
					$scope.accordName.push($scope.records[i].field_tgtField);
				}
			}

			var modelNew = $parse($scope.accordName[0]);
			modelNew.assign($scope, true);
			$ionicScrollDelegate.resize();
		}, 400);
	}

	$scope.SubmitFormData = function(sysid) {
		var ticketSys = document.getElementById("sysid").value;

		$scope.formData.u_spare_status = 'Returned', $scope.formData.u_temp_spare_return_date = todayDate, console.log($scope.formData)
		$http({
			method : 'PUT',
			url : $rootScope.baseAppURL + '/api/now/table/u_avery_temp_asset_usage/' + ticketSys,
			data : $scope.formData,
			headers : {
				'Content-Type' : 'application/json',
				'Accept' : 'application/json',
			},
		}).success(function(data, status, headers, config) {
			if (status == 200 || status == 201) {
				$state.go('eventmenu.home');
			}

		}).error(function(data, status, headers, config) {
			//Utils.showAlert(unableToUpload);
			//Utils.hidePleaseWait();
		});

	}
})