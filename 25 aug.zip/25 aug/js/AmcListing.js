angular.module('starter.controllers').controller('AmcListingCtrl', function($scope, $rootScope, $timeout, $state, $localstorage, $http, $window, database, Utils, applicationServices, $ionicScrollDelegate) {
	$scope.$parent.$parent.$parent.showTodayTaskIcon = true;
	$scope.$parent.$parent.$parent.app_page_title = 'AMC Listing';
	$scope.$parent.$parent.$parent.showBackButton = 'showBackButton';

	$scope.$parent.$parent.$parent.showLogo = '';
	$scope.totalRecords = '';
	$scope.totalRecordsBack = '';
	$scope.finalListing = [];
	$rootScope.setupHttpAuthHeader();
	$scope.noTicketFlag = false;

	$localstorage.setWithOutEncryption('PARTIAL_TICKET_DATA', '');

	$scope.backToTicketsListing = function() {
		if ($scope.openTicketCheckPhone()) {
			$state.go('eventmenu.myopenticketphone');
		} else {
			$state.go('eventmenu.home');
		}
	};

	$scope.showDetails = function(data) {
		$localstorage.set('SELECTED_ACCOUNT', angular.toJson(data));
		$state.go('eventmenu.visitdetailsedit');
	}
	try {
		var ssoid = $localstorage.get('SN-USER-NAME')
		database.getPendingTickets(ssoid, function(result) {

			$scope.pendingVDItems = [];

			//console.log(result)
			if (result && result.rows && result.rows.length > 0) {
				for (var i = result.rows.length - 1; i >= 0; i--) {
					var tktData = angular.fromJson(Tea.decrypt(result.rows.item(i).TicketInfo, $rootScope.dbpasscode));
					tktData.Type = result.rows.item(i).Type;

					if (result.rows.item(i).UserId == ssoid && result.rows.item(i).Type == 'VISIT_DETAILS_EDIT') {
						$scope.pendingVDItems.push(tktData);
						//console.log($scope.pendingVDItems)
					}

				}

			} else {
				$timeout(function() {
					$scope.pendingVDItems = [];
					//$scope.pendingSPItems = [];
					//$scope.pendingODRSPItems = [];
					//$scope.$apply();
					//this triggers a $digest
				}, 1000);
			}
		});
	} catch(e) {
	}

	$scope.allRecords = function() {
		$scope.nextActivity = false;
		try {
			Utils.showPleaseWait(pleaseWait);
			database.getVisitDetailsData(function(result) {
				//console.log(result)
				if (result && result.rows && result.rows.length > 0) {

					var applicationAccess = result.rows.item(0);

					$scope.totalRecords = angular.fromJson(applicationAccess.Data);

					for (var i = 0; i < $scope.totalRecords.length; i++) {
						for ( j = 0; j < $scope.totalRecords[i].length; j++) {
							if ($scope.totalRecords[i][j].field_name == 'r_activity_type') {
								if ($scope.totalRecords[i][j].field_refID == '42d1d6524fd3ba00def782818110c723' || $scope.totalRecords[i][j].field_refID == '68b156524fd3ba00def782818110c700') {
									$scope.finalListing.push($scope.totalRecords[i])
								}
							}

						}
					}

					$scope.totalRecordsBack = $scope.finalListing;

					//console.log($scope.totalRecords)
					$timeout(function() {// delay becuase ui takes some time to render
						$scope.noTicketFlag = true;
						Utils.hidePleaseWait();
					}, 500);
				} else {
					$scope.noTicketFlag = true;
					Utils.hidePleaseWait();
				}

			});
		} catch(e) {
			Utils.hidePleaseWait();
		}

	}

	$scope.filterAllActivity = function() {
		$scope.allRecords();
	}

	$scope.filterTodayActivity = function() {
		Utils.showPleaseWait(pleaseWait);
		$scope.selectedRow = 0;
		var totalEffort = 0;
		var currentDate = new Date();
		// console.log('current')
		//console.log(currentDate)
		var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
		$scope.nextDays = [];
		for (var i = 1; i <= 7; i++) {
			if (i == 1) {
				currentDate.setDate(currentDate.getDate());
			} else {
				currentDate.setDate(currentDate.getDate() + 1);
			}
			formattedDate = currentDate.toISOString().slice(0, 10);
			var n = formattedDate.lastIndexOf("-");
			var p = formattedDate.substring(n + 1, formattedDate.length);

			var d = new Date(formattedDate);
			//converts the string into date object
			var m = d.getMonth() + 1;
			//get the value of month
			if (m == 1) {
				month = 'Jan'
			} else if (m == 2) {
				month = 'Feb'
			} else if (m == 3) {
				month = 'Mar'
			} else if (m == 4) {
				month = 'Apr'
			} else if (m == 5) {
				month = 'May'
			} else if (m == 6) {
				month = 'Jun'
			} else if (m == 7) {
				month = 'Jul'
			} else if (m == 8) {
				month = 'Aug'
			} else if (m == 9) {
				month = 'Sep'
			} else if (m == 10) {
				month = 'Oct'
			} else if (m == 11) {
				month = 'Nov'
			} else if (m == 12) {
				month = 'Dec'
			}

			//Calulcating the total number of effortrs
			for (var k = 0; k < $scope.totalRecordsBack.length; k++) {
				for ( j = 0; j < $scope.totalRecordsBack[k].length; j++) {
					if ($scope.totalRecordsBack[k][j].field_name == 'u_acceptance_date') {
						if ($scope.totalRecordsBack[k][j].field_value == formattedDate) {
							for (var m = 0; m < $scope.totalRecordsBack[k].length; m++) {
								if ($scope.totalRecordsBack[k][m].field_name == 'u_activity_effort') {
									totalEffort = totalEffort + Number($scope.totalRecordsBack[k][m].field_value);
									//$scope.tempListing.push($scope.totalRecordsBack[i])
									break;
								}
							}
						}
					}
				}
			}

			$scope.nextDays.push({
				'fulldate' : formattedDate,
				'day' : p,
				'month' : month,
				'effort' : totalEffort
			})
			totalEffort = 0;

			console.log($scope.nextDays);
		}
		//$scope.selected = $scope.nextDays[0];
		// console.log($scope.nextDays);

		var tzoffset = (new Date()).getTimezoneOffset() * 60000;
		//offset in milliseconds
		var todayDate = (new Date(Date.now() - tzoffset)).toISOString().slice(0, 10);

		$scope.tempListing = [];
		for (var i = 0; i < $scope.totalRecordsBack.length; i++) {
			for ( j = 0; j < $scope.totalRecordsBack[i].length; j++) {
				if ($scope.totalRecordsBack[i][j].field_name == 'u_acceptance_date' && $scope.totalRecordsBack[i][j].field_value == todayDate) {
					$scope.tempListing.push($scope.totalRecordsBack[i])
					break;
				}
			}
		}
		$scope.finalListing = $scope.tempListing;
		$ionicScrollDelegate.scrollTop();
		Utils.hidePleaseWait();

		$scope.nextActivity = true;

	}

	$scope.updateNextDays = function(data, index) {
		console.log(data);

		$scope.selectedRow = null;
		// initialize our variable to null

		$scope.selectedRow = index;
		console.log($scope.totalRecordsBack)
		console.log(data.fulldate)
		$scope.tempListing = [];
		for (var i = 0; i < $scope.totalRecordsBack.length; i++) {
			for ( j = 0; j < $scope.totalRecordsBack[i].length; j++) {
				if ($scope.totalRecordsBack[i][j].field_name == 'u_acceptance_date' && $scope.totalRecordsBack[i][j].field_value == data.fulldate) {
					$scope.tempListing.push($scope.totalRecordsBack[i])
					break;
				}
			}
		}
		$scope.finalListing = $scope.tempListing;
		$ionicScrollDelegate.scrollTop();
		Utils.hidePleaseWait();
	}

	$scope.filterSuspended = function() {
		$scope.nextActivity = false;
		$scope.nextActivity = false;
		$scope.tempListing = [];
		for (var i = 0; i < $scope.totalRecordsBack.length; i++) {
			for ( j = 0; j < $scope.totalRecordsBack[i].length; j++) {
				if ($scope.totalRecordsBack[i][j].field_name == 'u_status' && $scope.totalRecordsBack[i][j].field_value == 'Suspend') {
					$scope.tempListing.push($scope.totalRecordsBack[i])
					break;
				}
			}
		}
		$scope.finalListing = $scope.tempListing;
		$ionicScrollDelegate.scrollTop();
		Utils.hidePleaseWait();
	}

	$scope.filterDuein7Days = function() {
		$scope.nextActivity = false;
		var now = new Date();

		var todayDate = now.setHours(0, 0, 0, 0)

		var nextWeek = new Date(now);
		nextWeek.setDate(nextWeek.getDate() + 7);

		function toDate(dateStr) {
			var array = dateStr.split('-'), year = array[0], month = array[1], day = array[2];
			return new Date(year, month - 1, day)
		}

		//console.log(toDate('2017-09-09'));

		$scope.tempListing = [];
		for (var i = 0; i < $scope.totalRecordsBack.length; i++) {
			for ( j = 0; j < $scope.totalRecordsBack[i].length; j++) {
				if ($scope.totalRecordsBack[i][j].field_name == 'u_due_date') {
					if ($scope.totalRecordsBack[i][j].field_value) {
						var ticketDate = toDate($scope.totalRecordsBack[i][j].field_value);
						console.log(ticketDate)
						//console.log(ticketDate)
						console.log(todayDate)
						console.log(nextWeek)
						if (ticketDate > todayDate && ticketDate < nextWeek) {
							$scope.tempListing.push($scope.totalRecordsBack[i]);
							break;
						}

					}
				}
			}
		}
		$scope.finalListing = $scope.tempListing;
		$ionicScrollDelegate.scrollTop();
		Utils.hidePleaseWait();
	}

	$scope.customFilter = function(p, s) {

		console.log(p, s)

		$scope.tempListing = [];
		if (p && s) {

			for (var i = 0; i < $scope.totalRecordsBack.length; i++) {
				for ( j = 0; j < $scope.totalRecordsBack[i].length; j++) {
					if ($scope.totalRecordsBack[i][j].field_name == 'u_activity_priority' && $scope.totalRecordsBack[i][j].field_value == p && $scope.totalRecordsBack[i][j].field_name == 'u_status' && $scope.totalRecordsBack[i][j].field_value == s) {
						$scope.tempListing.push($scope.totalRecordsBack[i])
						break;
					}
				}
			}
		} else if (p && s) {
			for (var i = 0; i < $scope.totalRecordsBack.length; i++) {
				for ( j = 0; j < $scope.totalRecordsBack[i].length; j++) {
					if ($scope.totalRecordsBack[i][j].field_name == 'u_activity_priority' && $scope.totalRecordsBack[i][j].field_value == s) {
						$scope.tempListing.push($scope.totalRecordsBack[i])
						break;
					}
				}
			}
		} else if (!p && s) {
			for (var i = 0; i < $scope.totalRecordsBack.length; i++) {
				for ( j = 0; j < $scope.totalRecordsBack[i].length; j++) {
					if ($scope.totalRecordsBack[i][j].field_name == 'u_status' && $scope.totalRecordsBack[i][j].field_value == s) {
						$scope.tempListing.push($scope.totalRecordsBack[i])
						break;
					}
				}
			}

		}

		$scope.finalListing = $scope.tempListing;
		$ionicScrollDelegate.scrollTop();
		Utils.hidePleaseWait();
		document.getElementById("mySidenav").style.width = "0";
		//document.getElementById("main").style.marginLeft= "0";
	}
	/*$scope.isInvalid = function(data){
	 var className = '';
	 var a;
	 var b;
	 var c;
	 for(var i=0; i<data.length;i++){
	 if(data[i].field_name == 'u_esc1' && data[i].field_value == 'false'){
	 a = true;
	 } else if(data[i].field_name == 'u_esc2' && data[i].field_value == 'false'){
	 b = true
	 } else if(data[i].field_name == 'u_esc3' && data[i].field_value == 'false'){
	 c = true
	 } else {
	 }
	 }
	 if(a == true){
	 className = 'yellow';
	 return className;
	 }

	 }*/

	$scope.openNav = function() {
		if (document.getElementById("mySidenav").style.width == '250px') {
			document.getElementById("mySidenav").style.width = "0";
		} else {
			document.getElementById("mySidenav").style.width = "250px";
		}
		// document.getElementById("main").style.marginLeft = "250px";
	}

	$scope.closeNav = function() {
		document.getElementById("mySidenav").style.width = "0";
		document.getElementById("main").style.marginLeft = "0";
	}

	$scope.allRecords();

})
