angular.module('starter.controllers').controller('VisitDetailsCtrl', function($scope, $rootScope, $timeout, $state, $localstorage, $http, $window, database, Utils, applicationServices, $ionicPopup, $parse, $ionicScrollDelegate, $interval) {
	$scope.$parent.$parent.$parent.showTodayTaskIcon = false;

	$scope.$parent.$parent.$parent.showBackButton = 'showBackButton';
	$scope.$parent.$parent.$parent.showLogo = '';

	$rootScope.setupHttpAuthHeader();
	$scope.ticketform = {};
	$scope.partialform = {};
	$scope.checklistForm = {};
	$scope.ticketform.u_sre_latitude = '';
	$scope.ticketform.u_sre_longitude = ''
	$scope.show_section = {};
	$scope.showSpareParts = false;
	$scope.isSignPad = false;
	$scope.noTicketFlag = false;
	
	var ssoid = $localstorage.get('SN-USER-NAME');
	var sysId = $localstorage.get('SN-USER-SYSID');

	var now = new Date();
	var tzoffset = (now).getTimezoneOffset() * 60000;
	//offset in milliseconds
	var todayDate = (new Date(Date.now() - tzoffset)).toISOString().slice(0, 10);

	function validateEmail(email) {// Email Validation
		var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(email);
	}

	// Accordion Display
	$scope.section_click = function(section, $event) {
		$scope[section] = !$scope[section];
		$ionicScrollDelegate.resize();
		//$scope.closeAllAccord(section);
	};

	$scope.toggleGroup = function(group) {
		if ($scope.isGroupShown(group)) {
			$scope.shownGroup = null;
		} else {
			$scope.shownGroup = group;
		}
	};
	$scope.isGroupShown = function(group) {
		return $scope.shownGroup === group;
	};

	$scope.openTicketCheckPhone = function() {
		if ($('#openTicketCheckPhone').is(':hidden')) {
			return false;
		} else {
			return true;
		}
	};

	$scope.backToTicketsListing = function() {
		if ($scope.openTicketCheckPhone()) {
			//$state.go('eventmenu.myopenticketphone');
			$state.go('eventmenu.home');
		} else {
			$state.go('eventmenu.home');
		}
	};

	// Accordion Options
	$scope.closeAllAccord = function(section) {

		for (var i = 0; i < $scope.accordName.length; i++) {
			if ($scope.accordName[i] == section) {
				$scope[section] = true;
			} else {
				var modelNew = $parse($scope.accordName[i]);
				modelNew.assign($scope, false);
			}
			$ionicScrollDelegate.resize();
		}
	}

	$scope.createUI = function() {
		//console.log('ui called')
		
		// Check if same ticket is in pending que
		try {
			var ssoid = $localstorage.get('SN-USER-NAME')
			database.getPendingTickets(ssoid, function(result) {
				
				$scope.pendingVDItems = [];
				//console.log(result)
				if (result && result.rows && result.rows.length > 0) {
					for (var i = result.rows.length - 1; i >= 0; i--) {
						var tktData = angular.fromJson(Tea.decrypt(result.rows.item(i).TicketInfo, $rootScope.dbpasscode));
						tktData.Type = result.rows.item(i).Type;						
						if (result.rows.item(i).UserId == ssoid && result.rows.item(i).Type == 'JobDetails') {
							$scope.pendingVDItems.push(tktData);
							//console.log($scope.pendingVDItems)
						}
						

					}					

				} else {
					 $timeout(function() {
						$scope.pendingVDItems = [];
						//$scope.pendingSPItems = [];
						//$scope.pendingODRSPItems = [];
						//$scope.$apply();
						//this triggers a $digest
					}, 1000);
				}
			});
		} catch(e) {
		}
		
		// End of checking in pending que
		
		
		// Get the selected record from local storage
		var selectedItem = $localstorage.get('SELECTED_ACCOUNT');
		$scope.records = angular.fromJson(selectedItem);
		//console.log('main called')
		console.log($scope.records)

		// Get the Partial Saved data from local storage
		var partialData = $localstorage.getWithOutEncryption('PARTIAL_TICKET_DATA');
		if (partialData && partialData.length > 0) {
			$scope.filledData = angular.fromJson(partialData);
			for (var i = 0; i < $scope.records.length; i++) {
				if ($scope.records[i].field_Visible == 'true' && $scope.records[i].field_readonly == 'false') {
					var namee = $scope.records[i].field_name;
					$scope.records[i].field_value = $scope.filledData[namee];
				}
			}
		}

		// Create the Choice options, get the ticket status and create dynamic name
		$scope.accordName = [];

		for (var i = 0; i < $scope.records.length; i++) {

			if ($scope.records[i].field_type == 'choice') {
				var name = $scope.records[i].field_name;
				$scope.choiceValue = $scope.records[i].field_choiceValue;
				var the_string = name;
				// Get the model
				var model = $parse(the_string);
				// Assigns a value to it
				model.assign($scope, $scope.choiceValue);

			} else if ($scope.records[i].field_lable == 'Status') {
				$scope.currentFormStatus = $scope.records[i].field_value;
			} else if ($scope.records[i].field_type == 'date' && $scope.records[i].field_value != '') {
				var formDate = $scope.records[i].field_value;
				$scope.records[i].field_value = new Date(formDate.slice(0, 4), (formDate.slice(5, 7)) - 1, formDate.slice(8, 10));
			} else if ($scope.records[i].field_type == 'acc_start') {
				$scope.accordName.push($scope.records[i].field_tgtField);
			} else if ($scope.records[i].field_lable == 'Customer Latitude') {
				$scope.custLatitude = $scope.records[i].field_value;
			} else if ($scope.records[i].field_lable == 'Customer Longitude') {
				$scope.custLongitude = $scope.records[i].field_value;
			} else if ($scope.records[i].field_name == 'number') {
				$scope.ticketNumber = $scope.records[i].field_value;
			} else if ($scope.records[i].field_name == 'u_avery_checklist') {
				$scope.checklistSysId = $scope.records[i].field_value;

			} else if ($scope.records[i].field_name == 'sys_id') {
				$scope.ticketSysId = $scope.records[i].field_value;

			} else {
			}
		}

		//Seetting page title as ticket number
		$scope.$parent.$parent.$parent.app_page_title = $scope.ticketNumber;

		// By default accordion open
		$timeout(function() {
			//console.log($scope.currentFormStatus)
			if ($scope.currentFormStatus == 'Owner Assigned') {
				$scope.closeAllAccord('chk_start_home');
			} else if ($scope.currentFormStatus == 'Start Work') {
				$scope.closeAllAccord('chk_end_work');
			} else if ($scope.currentFormStatus == 'First Response' || $scope.currentFormStatus == 'New') {
				$scope.closeAllAccord('acceptance_details');
			} else if ($scope.currentFormStatus == 'Suspend') {
				$scope.closeAllAccord('acceptance_details');
			} else {
			}
		}, 500);

	}

	$scope.validateChoice = function(type) {

		var isChoiceValid = 'true';
		

		//console.log($scope.ticketform)

		// For Suspend Checklist
		if (type == 'chk_suspention') {
			
			if(!$scope.ticketform.u_chk_susp_msv_std){
					$('#u_chk_susp_msv_std').addClass('errorAsterisk');
					$('#u_justification_for_suspension').addClass('errorAsterisk');
					$('#u_suspend_with_temporary_fix').addClass('errorAsterisk');
					Utils.showAlert("Please select the Reason for Suspension");
					var isChoiceValid = 'false';
					return false;
			} else if(!$scope.ticketform.u_justification_for_suspension){
				$('#u_chk_susp_msv_std').addClass('errorAsterisk');
					$('#u_chk_susp_msv_std').addClass('errorAsterisk');
					$('#u_justification_for_suspension').addClass('errorAsterisk');
					$('#u_suspend_with_temporary_fix').addClass('errorAsterisk');
					Utils.showAlert("Please enter the Justification for Suspension");
					var isChoiceValid = 'false';
					return false;				
			} else if(!$scope.ticketform.u_suspend_with_temporary_fix){
				$('#u_chk_susp_msv_std').addClass('errorAsterisk');
					$('#u_chk_susp_msv_std').addClass('errorAsterisk');
					$('#u_justification_for_suspension').addClass('errorAsterisk');
					$('#u_suspend_with_temporary_fix').addClass('errorAsterisk');
					Utils.showAlert("Please select the Suspend with Temp Fix");
					var isChoiceValid = 'false';
					return false;				
			} else if($scope.ticketform.u_chk_susp_msv_std && $scope.ticketform.u_chk_susp_msv_std == 'Spare Required'){
					if (!$scope.ticketform.u_qty_for_spare_1 || !$scope.ticketform.u_new_spare_1) {
						Utils.showAlert("Please enter the New Spare details and Spare Quantity");			
						$('#u_qty_for_spare_1').addClass('errorAsterisk');
						$('#u_new_spare_1').addClass('errorAsterisk');
						$('#u_cost_included').addClass('errorAsterisk');
						var isChoiceValid = 'false';
						return false;
					} else if($scope.ticketform.u_new_spare_1 && $scope.ticketform.u_qty_for_spare_1 && $scope.ticketform.u_qty_for_spare_1 < 1){
						Utils.showAlert("Spare Quantity should be more than 1");
						var isChoiceValid = 'false';
						return false;
					} else if(!$scope.ticketform.u_cost_included){
						Utils.showAlert("Please select the Quote to Customer");
						var isChoiceValid = 'false';
						return false;
					} 
				
			} else {
						$('#u_qty_for_spare_1').removeClass('errorAsterisk');
						$('#u_new_spare_1').removeClass('errorAsterisk');
						$('#u_cost_included').removeClass('errorAsterisk');
			}
			
			
			

			if ($scope.ticketform.u_suspend_with_temporary_fix == 'yes' || $scope.ticketform.u_suspend_with_temporary_fix == 'Yes') {
				if (!$scope.ticketform.u_temp_solution_proposed) {
					Utils.showAlert("Please provide the temp solution proposed");					
					$('#u_temp_solution_proposed').addClass('errorAsterisk');					
					isChoiceValid = false;
					return false;
					//break;
				}
			} else {
				$('#u_temp_solution_proposed').removeClass('errorAsterisk');	
			}
			

			if ($scope.ticketform.u_cost_included) {
				if ($scope.ticketform.u_cost_included.toLowerCase() == 'yes') {
					if (!$scope.ticketform.u_reason_for_quote_to_customer || !$scope.ticketform.u_customer_email) {
						Utils.showAlert("Please enter the reason for Quote to Customer & Customer Email id");
						
						$('#u_reason_for_quote_to_customer').addClass('errorAsterisk');
						$('#u_customer_email').addClass('errorAsterisk');
						$scope.closeAllAccord('chk_suspention');
						isChoiceValid = false;
						return false;
						//break;
					} else if ($scope.ticketform.u_customer_email) {
						var checkEmail = validateEmail($scope.ticketform.u_customer_email);
						if (checkEmail == true) {
							return true;
							//break;
						} else {
							Utils.showAlert("Please enter the correct email id");
							
							$scope.closeAllAccord('chk_suspention');
							isChoiceValid = false;
							return false;							
						}
					}
				} else {
					$('#u_reason_for_quote_to_customer').removeClass('errorAsterisk');
					$('#u_customer_email').removeClass('errorAsterisk');
				}
			}

			if (isChoiceValid == 'true') {
				return true;
			}

		}

		// End work checklist

		if (type == 'chk_end_work') {
			for (var i = 0; i < $scope.records.length; i++) {
				if ($scope.records[i].acc_src == 'chk_end_work') {
					var otherChoiceVal = '';
					var commentsVal = '';
					$('#u_breakdown_comments').removeClass('errorAsterisk');

					if ($scope.records[i].field_type == 'choice' && !$scope.records[i].field_value) {
						$('#' + $scope.records[i].field_name).addClass('errorAsterisk');
						$scope.endWorkChecklist = 'true';
						$scope.isChoiceFilled = 'false';
						Utils.showAlert("Please enter the value for all mandatory fields");
						isChoiceValid = false;
						return false;	

					}

					if ($scope.records[i].field_type == 'choice' && $scope.records[i].field_lable.indexOf('thers') !== -1) {						
						$scope.otherChoiceVal = $scope.records[i].field_value;
						check1 = 'true';
						
					}
					if ($scope.records[i].field_lable.indexOf('omments') !== -1) {
						$scope.commentsVal = $scope.records[i].field_value;
						check2 = 'true';
						
					}
					
					if (isChoiceValid == 'true' && check1 == 'true' && check2 == 'true') {						
						if (($scope.otherChoiceVal == 'yes' || $scope.otherChoiceVal == 'Yes') && !$scope.commentsVal) {
							Utils.showAlert("Please fill the comments");
							$('#u_breakdown_comments').addClass('errorAsterisk');
							isChoiceValid = false;
							return false;
						} else {
							$('#u_breakdown_comments').removeClass('errorAsterisk');							
							return true;
						}
					}
					
				}

			}// End of for loop
		}

		if (type == 'chk_start_home') {
			for (var i = 0; i < $scope.records.length; i++) {
				if ($scope.records[i].acc_src == 'chk_start_home') {
					if ($scope.records[i].field_type == 'choice' && !$scope.records[i].field_value) {
						//$('#'+$scope.records[i].field_name).addClass('errorAsterisk');
						$scope.startHomeChecklist = 'true';
						$scope.isChoiceFilled = 'false';
						//$('#u_carrying_temp_asset_1').addClass('errorAsterisk');
						//$('#u_carrying_temp_asset_qty_1').addClass('errorAsterisk');
						Utils.showAlert("Please enter the value for all mandatory fields");
						break;

					} else {
						return true;
					}
						

					/*if (!$scope.ticketform.u_carrying_temp_asset_1 || !$scope.ticketform.u_carrying_temp_asset_qty_1) {
						Utils.showAlert("Please enter the Carrying Spare & Quantity");
						break;
					} else {
						return true;
					}*/
				}
			}

			/*else if($scope.records[i].acc_src == type){

			 if($scope.records[i].field_type=='choice' && !$scope.records[i].field_value){

			 //console.log($scope.records[i].field_value)
			 $scope.isChoiceFilled = 'false';

			 Utils.showAlert("Please enter the value for all mandatory fields");
			 break;

			 } else if($scope.records[i].field_lable.indexOf('thers') !== -1){
			 var otherChoiceVal = $scope.records[i].field_value;
			 }
			 else if($scope.records[i].field_lable.indexOf('omments') !== -1){
			 var commentsVal = $scope.records[i].field_value;
			 }

			 }
			 */	/*if(isChoiceValid == 'true' && i == ($scope.records.length)-1){

			 if(type != 'chk_start_home'){
			 if(otherChoiceVal == 'yes' || otherChoiceVal == 'Yes' && !commentsVal){
			 Utils.showAlert("Please fill the comments");
			 } else {
			 return true;
			 }
			 }
			 else {
			 return true;
			 }
			 } */
		} // end of for loop

	}

	$scope.validateResume = function(type) {
		
		if(!$scope.ticketform.u_justification_for_resumption_sus || !$scope.ticketform.u_acceptance_date || !$scope.ticketform.u_accepted_time_slot){
				Utils.showAlert("Please fill the mandatory field");
				return false;
		} else if($scope.ticketform.u_acceptance_date){
			
						var selectedAcceptDate = new Date($scope.ticketform.u_acceptance_date);
						var todayDate = new Date();
						todayDate.setHours(0, 0, 0, 0);
						
						if (!(selectedAcceptDate >= todayDate)) {// back date validation
							$timeout(function() {
								Utils.showAlert('Accepted date can not be the past date.');
								return false;
							}, 100);
						} else {
							return true;	
						}
		}
		
		
	}
	// On Form Submit
	$scope.SubmitFormData = function(btnType) {

		// Get the position
		var options = {
			enableHighAccuracy : true,
			timeout : 5000,
			maximumAge : 0
		};
		var onSuccess = function(position) {
			$scope.ticketform.u_sre_latitude = position.coords.latitude;
			$scope.ticketform.u_sre_longitude = position.coords.longitude;
		};

		function onError(error) {	}

		try {
			navigator.geolocation.getCurrentPosition(onSuccess, onError, options);
		} catch(e) {

		}

		for (var i = 0; i < $scope.records.length; i++) {
			if ($scope.records[i].field_name == 'sys_id' || $scope.records[i].field_name == 'number' || ($scope.records[i].field_readonly == 'false' && $scope.records[i].field_Visible == 'true')) {
				var namee = $scope.records[i].field_name;
				if ($scope.records[i].field_type == "date" && $scope.records[i].field_value) {
					date = new Date($scope.records[i].field_value);
					year = date.getFullYear();
					month = date.getMonth() + 1;
					dt = date.getDate();

					if (dt < 10) {
						dt = '0' + dt;
					}
					if (month < 10) {
						month = '0' + month;
					}
					$scope.ticketform[namee] = year + '-' + month + '-' + dt;
					//console.log(year+'-' + month + '-'+dt);
				} else if ($scope.records[i].field_type == 'REF') {
					$scope.ticketform[namee] = $scope.records[i].field_refID;
					$scope.checklistForm[namee] = $scope.records[i].field_refID;
				} else {
					$scope.ticketform[namee] = $scope.records[i].field_value;

					if (($scope.records[i].acc_src == 'chk_start_home' || $scope.records[i].acc_src == 'chk_end_work' || $scope.records[i].acc_src == 'chk_suspention')) {// For checklist options
						//var nameee = $scope.records[i].field_name;
						$scope.checklistForm[namee] = $scope.records[i].field_value;

					}
				}

			}
		}

		if (btnType == 'Accept') {

			var confirmPopup = $ionicPopup.confirm({
				title : '',
				template : 'Have you taken PRIOR customer appointment for the job?'
			});

			confirmPopup.then(function(res) {
				if (res) {
					if (!($scope.ticketform.u_acceptance_date && $scope.ticketform.u_acceptance_date.length > 0)) {
						$timeout(function() {
							Utils.showAlert(acceptanceDate);
							return false;
							//$scope.uploadTicketProcess();

						}, 100);

					} else if($scope.ticketform.u_acceptance_date) {

						var selectedAcceptedDate = new Date($scope.ticketform.u_acceptance_date);
						var todayDate = new Date();
						todayDate.setHours(0, 0, 0, 0)

						if (!(selectedAcceptedDate >= todayDate)) {// back date validation
							$timeout(function() {
								Utils.showAlert('Accepted date can not be the past date.');
								return false;
							}, 100);
						} else {
							if (!($scope.ticketform.u_accepted_time_slot && $scope.ticketform.u_accepted_time_slot.length > 0)) {
								$timeout(function() {
									Utils.showAlert(acceptanceTimeSlot);
									return false;
									//$scope.uploadTicketProcess();
		
								}, 100);
								} else {
									$scope.ticketform.u_status = 'Owner Assigned';
									$scope.uploadTicketProcess();
								}	
						}
					} 
						
					

				} else {
					console.log('You are not sure');
				}
			});

		} else if (btnType == 'First Response') {
			if ($scope.ticketform.u_first_response_comment == '') {
				Utils.showAlert("Please fill the first response");
			} else {
				$scope.ticketform.u_status = 'New';
				$scope.uploadTicketProcess();
			}
		} else if (btnType == 'Approve') {
			$scope.ticketform.u_status = 'New';
			$scope.uploadTicketProcess();
		} else if (btnType == 'Start Travel Forward') {
			$scope.closeAllAccord('chk_start_home');
			if ($scope.validateChoice('chk_start_home')) {
				$scope.ticketform.u_accept_on_start = todayDate;
				$scope.ticketform.u_status = 'Start Travel Forward';
				$scope.uploadTicketProcess();
			}

		} else if (btnType == 'End Travel Forwward') {
			$scope.ticketform.u_status = 'End Travel Forward';
			$scope.uploadTicketProcess();
		} else if (btnType == 'Start Work') {
			$scope.ticketform.u_status = 'Start Work';
			$scope.uploadTicketProcess();
		} else if (btnType == 'End Work') {
			$scope.closeAllAccord('chk_end_work');

			if ($scope.validateChoice('chk_end_work')) {
				$scope.ticketform.u_status = 'End Work';
				$scope.uploadTicketProcess();

			}

		} else if (btnType == 'Start Travel Back') {
			$scope.ticketform.u_status = 'Start Travel Back';
			$scope.uploadTicketProcess();
		} else if (btnType == 'Completed') {
			$scope.ticketform.u_status = 'Completed';
			$scope.uploadTicketProcess();
		} else if (btnType == 'End Travel Back') {
			$scope.ticketform.u_status = 'Completed';
			$scope.uploadTicketProcess();
		} else if (btnType == 'Suspend') {
			$scope.closeAllAccord('chk_suspention');
			//console.log($scope.records[i].field_value)
			$scope.chk_suspention = 'true';
			if ($scope.validateChoice('chk_suspention')) {
				$scope.ticketform.u_status = 'Suspend';
				$scope.uploadTicketProcess();

			}

		} else if (btnType == 'Resume') {
			if ($scope.validateResume('chk_suspention')) {
				$scope.ticketform.u_status = 'Owner Assigned';
				$scope.uploadTicketProcess();
			}

		} else {

		}
	}
	//only update current record with attachment
	$scope.UpdateRecord = function() {
		console.log($scope.records)
		for (var i = 0; i < $scope.records.length; i++) {
			if ($scope.records[i].field_name == 'sys_id' || $scope.records[i].field_name == 'number' || ($scope.records[i].field_readonly == 'false' && $scope.records[i].field_Visible == 'true')) {
				var namee = $scope.records[i].field_name;
				if ($scope.records[i].field_type == "date" && $scope.records[i].field_value) {
					date = new Date($scope.records[i].field_value);
					year = date.getFullYear();
					month = date.getMonth() + 1;
					dt = date.getDate();

					if (dt < 10) {
						dt = '0' + dt;
					}
					if (month < 10) {
						month = '0' + month;
					}
					$scope.ticketform[namee] = year + '-' + month + '-' + dt;
					//console.log(year+'-' + month + '-'+dt);
				} else if ($scope.records[i].field_type == 'REF') {
					$scope.ticketform[namee] = $scope.records[i].field_refID;
					$scope.checklistForm[namee] = $scope.records[i].field_refID;
				} else {
					$scope.ticketform[namee] = $scope.records[i].field_value;

					if (($scope.records[i].acc_src == 'chk_start_home' || $scope.records[i].acc_src == 'chk_end_work' || $scope.records[i].acc_src == 'chk_suspention') && $scope.records[i].field_readonly == 'false') {// For checklist options
						//var nameee = $scope.records[i].field_name;
						$scope.checklistForm[namee] = $scope.records[i].field_value;

					}
				}

			}
		}
		$scope.uploadTicketProcess();
	}

	$scope.uploadTicketProcess = function() {
		//alert('Lat:'+$scope.ticketform.u_sre_latitude+', Long: '+ $scope.ticketform.u_sre_longitude);

		Utils.showPleaseWait(pleaseWait);

		if (ssoid) {
			var d = new Date();
			var n = d.getTime();
			$scope.ticketform.ticketId = "" + n;
			$scope.ticketform.savedTS = "" + n;
			$scope.ticketform.u_updated_by = sysId;
			$scope.ticketform.u_update_from = 'mobile';
			
			if($scope.ticketform.u_sre_latitude == '' || $scope.ticketform.u_sre_longitude == ''){ // If location is blank then set it from local data			
			var userLocation = $localstorage.getWithOutEncryption('USER-LOCATION');
				if (userLocation) {
					var n = userLocation.indexOf(",");
					$scope.ticketform.u_sre_latitude = userLocation.substring(0, n);					
					$scope.ticketform.u_sre_longitude = userLocation.substring(n + 1, userLocation.length);
				}
			}
			
			if ($rootScope.isOnline()) {
				console.log($scope.ticketform)
				console.log($scope.checklistForm)
				$scope.uploadTicket();
			} else {

				//Save it locally for future upload process
				database.storePendingTicket($scope.ticketform.ticketId, ssoid, "JobDetails", $scope.ticketform.savedTS, $scope.ticketform, function(status) {
					$scope.ticketform = {};
					Utils.hidePleaseWait();
					$scope.backToTicketsListing();
				});
			}
		}

	}
	/**
	 *Upload ticket to server in online mode
	 */
	$scope.uploadTicket = function() {

		//$scope.ticketform.u_status = "Closed";
		$http({
			method : 'PUT',
			url : $rootScope.baseAppURL + '/api/now/table/u_avery_workreq_task/' + $scope.ticketform.sys_id + '?sysparm_fields=number',
			data : $scope.ticketform,
			headers : {
				'Content-Type' : 'application/json',
				'Accept' : 'application/json',
			},
		}).success(function(data, status, headers, config) {
			if (status == 200) {
				$scope.uploadChoice();
				$scope.uploadImage();
			}

		}).error(function(data, status, headers, config) {
			Utils.showAlert(unableToUpload);
			Utils.hidePleaseWait();
		});
	};

	// Saving Partial Data
	$scope.openCustomerInformation = function(custID) {
		$localstorage.setWithOutEncryption('CUST-SYS-ID', custID);
		for (var i = 0; i < $scope.records.length; i++) {
			if ($scope.records[i].field_Visible == 'true' && $scope.records[i].field_readonly == 'false') {
				var namee = $scope.records[i].field_name;
				$scope.partialform[namee] = $scope.records[i].field_value;
			}
		}

		$localstorage.setWithOutEncryption('PARTIAL_TICKET_DATA', JSON.stringify($scope.partialform));

		$state.go('eventmenu.custinfoedit');
	}
	// Call the customer and open dialer
	$scope.callDialer = function(number) {
		function onSuccess(result) {
		}

		function onError(result) {
			//alert('error'+result)
		}

		if (number && number.length > 0) {
			window.plugins.CallNumber.callNumber(onSuccess, onError, number, true);
		} else {
			Utils.showAlert("Contact number not available");
		}
	}
	// Open Map
	$scope.showDirection = function() {
		if ($rootScope.isOnline()) {
			for (var i = 0; i < $scope.records.length; i++) {
				if ($scope.records[i].field_Visible == 'true' && $scope.records[i].field_readonly == 'false') {
					var namee = $scope.records[i].field_name;
					$scope.partialform[namee] = $scope.records[i].field_value;
				}
			}
			//console.log($scope.partialform)
			$localstorage.setWithOutEncryption('PARTIAL_TICKET_DATA', JSON.stringify($scope.partialform));

			$localstorage.setWithOutEncryption('CUST-LOCATION', $scope.custLatitude + ',' + $scope.custLongitude);
			// Setting Customer location for map screen
			$scope.userLocation = $localstorage.getWithOutEncryption('USER-LOCATION');
			// Getting user location
			//console.log($scope.custLatitude);
			//console.log($scope.custLongitude.length);

			if (!$scope.userLocation) {
				var options = {
					enableHighAccuracy : true,
					timeout : 5000,
					maximumAge : 0
				};
				var onSuccess = function(position) {

					$scope.userLocation = position.coords.latitude + ',' + position.coords.longitude;
					$localstorage.setWithOutEncryption('USER-LOCATION', $scope.userLocation)
				};
				function onError(error) {
				}

				try {

					navigator.geolocation.getCurrentPosition(onSuccess, onError, options);

				} catch(e) {

				}
			}
			$timeout(function() {
				if (($scope.custLatitude && $scope.custLongitude) && ($scope.custLatitude.length > 1 && $scope.custLongitude.length > 1)) {
					if ($scope.userLocation) {
						$state.go('eventmenu.customerlocation');
					} else {
						Utils.showAlert('Unable to detect your location, kindly make sure to on the GPS');
					}
				} else {
					Utils.showAlert('Customer location is not correct');
				}
			}, 800);
		} else {
			Utils.showAlert(networkError);
		}
	}

	$scope.activeJobsMap = function() {
		if ($rootScope.isOnline()) {
			for (var i = 0; i < $scope.records.length; i++) {
				if ($scope.records[i].field_Visible == 'true' && $scope.records[i].field_readonly == 'false') {
					var namee = $scope.records[i].field_name;
					$scope.partialform[namee] = $scope.records[i].field_value;
				}
			}
			//console.log($scope.partialform)
			$localstorage.setWithOutEncryption('PARTIAL_TICKET_DATA', JSON.stringify($scope.partialform));
			$localstorage.setWithOutEncryption('Current-Ticket', $scope.ticketNumber);
			$state.go('eventmenu.googlemap');
		} else {
			Utils.showAlert(networkError);
		}
	}
	// Open Attached images
	$scope.openAttachedImages = function(data) {
		$scope.showAttachment = true;
		//$scope.attachmentSource = $rootScope.baseAppURL + '/sys_attachment.do?sysparm_referring_url=tear_off&view=true&sys_id=' + data;
		//$scope.attachmentSource = $rootScope.baseAppURL + '/sys_attachment.do?sysparm_referring_url=tear_off&view=true&sys_id=' + data;

		//cordova.InAppBrowser.open($rootScope.baseAppURL + '/sys_attachment.do?sysparm_referring_url=tear_off&view=true&sys_id=1f9e7fb2bb508b00a7331272dbdb75a1', '_blank', 'location=yes,toolbar=yes');

		//cordova.InAppBrowser.open($rootScope.baseAppURL + '/sys_attachment.do?sysparm_referring_url=tear_off&view=true&sys_id='+data, '_blank', 'location=yes,toolbar=yes');

		cordova.InAppBrowser.open($rootScope.baseAppURL + '/sys_attachment.do?sysparm_referring_url=tear_off&view=true&sys_id=' + data, '_system', 'location=no,toolbar=no');

	}

	$scope.hideAttachment = function() {
		$scope.showAttachment = false;
	}
	// Open Contract Number
	$scope.openContract = function(data) {
		$localstorage.setWithOutEncryption('CUST-SYS-ID', data);
		for (var i = 0; i < $scope.records.length; i++) {
			if ($scope.records[i].field_Visible == 'true' && $scope.records[i].field_readonly == 'false') {
				var namee = $scope.records[i].field_name;
				$scope.partialform[namee] = $scope.records[i].field_value;
			}
		}

		$localstorage.setWithOutEncryption('PARTIAL_TICKET_DATA', JSON.stringify($scope.partialform));

		$state.go('eventmenu.servicecontractedit');
	}
	// Get the Carrying Spares/Tools Data  /sys_attachment.do?sysparm_referring_url=tear_off&view=true&sys_id=2e90049f4f71120031577d2ca310c7a1'

	$scope.openSpareDetails = function(isReasonly, fltr, fldId) {
	$scope.noTicketFlag = false;
		if (isReasonly != 'true') {

			try {
				$scope.toolsData = [];
				$scope.temp = [];
				
				$timeout(function() {
					$scope.noTicketFlag = true;
				}, 1000);
				
				
				var str = fltr;
				var n = str.indexOf("=");
				var filter1 = str.substring(0, n);
				//alert(res1);
				var filter2 = str.substring(n + 1, str.length);

				database.getCarryingToolsData(function(result) {					
					$scope.toolsData = [];
					if (result && result.rows.length > 0) {
						
						try {
							for (var i = 0; i < result.rows.length; i++) {
								//console.log(angular.fromJson(result.rows.item(i).Data))
								var applicationAccess = result.rows.item(i);
								$scope.temp = (angular.fromJson(applicationAccess.Data));

								for (var j = 0; j < $scope.temp.length; j++) {
									//console.log($scope.temp[j])
									//if(($scope.temp[j].field_name == filter1 && $scope.temp[j].field_value == filter2) || $scope.temp[j].field_name == 'sys_id'){ // 3 july
									if (($scope.temp[j].field_name == filter1 && $scope.temp[j].field_value == filter2)) {
										var tempData = result.rows.item(i).Data;
										$scope.toolsData.push(angular.fromJson(tempData));
									}
								}
							}
						} catch(e) {
						}
						//Utils.hidePleaseWait();
					}

					Utils.hidePleaseWait();
				});
			} catch(e) {
				Utils.hidePleaseWait();
			}

			$scope.showSpareParts = true;
			$scope.noTicketFlag == 'true';
			$scope.tempFldId = fldId;
			$ionicScrollDelegate.scrollTop();
		}
	}

	$scope.selectedTempData = function(data) {
		for (var i = 0; i < data.length; i++) {
			if (data[i].field_name == 'u_model_number') {
				var valuePos = i;
			} else if (data[i].field_name == 'sys_id') {
				var sysPos = i;
			}
		}

		for (var j = 0; j < $scope.records.length; j++) {
			if ($scope.records[j].field_name == $scope.tempFldId) {
				//var namee = $scope.records[i].field_name;

				$scope.records[j].field_value = data[valuePos].field_value;
				$scope.records[j].field_refID = data[sysPos].field_value;
				$scope.showSpareParts = false;
				//$ionicScrollDelegate.scrollTop();
			}
		}
	}
	// End of Carrying Spares/Tools Data

	// Image Attachment

	function toDataUrl(url, callback, outputFormat) {

		var img = new Image();
		img.crossOrigin = 'Anonymous';
		img.onload = function() {
			var canvas = document.createElement('CANVAS');
			var ctx = canvas.getContext('2d');
			var dataURL;
			canvas.height = this.height;
			canvas.width = this.width;
			ctx.drawImage(this, 0, 0);
			dataURL = canvas.toDataURL(outputFormat);
			callback(dataURL);
			canvas = null;
		};
		img.src = url;
	}

	// Uploading Choice data in Ref table

	$scope.uploadChoice = function() {
		$scope.checklistForm.u_accept_start_checklist = true;
		$scope.checklistForm.u_accept_by_start = sysId;
		$scope.checklistForm.u_accept_on_start = todayDate;
		console.log($scope.checklistForm)
		//$scope.ticketform.u_status = "Closed";

		$http({
			method : 'PUT',
			url : $rootScope.baseAppURL + '/api/now/table/u_avery_checkpoint/' + $scope.checklistSysId,
			data : $scope.checklistForm,
			headers : {
				'Content-Type' : 'application/json',
				'Accept' : 'application/json',
			},
		}).success(function(data, status, headers, config) {
			if (status == 200) {

			}

		}).error(function(data, status, headers, config) {
			//Utils.showAlert(unableToUpload);
			//Utils.hidePleaseWait();
		});

	}
	var c = document.getElementById("signature");
	var ctx = c.getContext("2d");
	ctx.moveTo(0, 0);
	ctx.lineTo(200, 100);
	ctx.stroke();

	$scope.Signature = function() {
		$scope.isSignPad = true;

		var Signature = cordova.require('nl.codeyellow.signature.Signature');
		Signature.getSignature(function(imgData) {
			/* This is the "success" callback. */
			if (!imgData) {
				$scope.isSignPad = false;
				//alert('cancel');
				return;
			}// User clicked cancel, we got no image data.

			var canvas = document.getElementById('signature'), ctx = canvas.getContext('2d');
			canvas.width = imgData.width;
			canvas.height = imgData.height;
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			ctx.putImageData(imgData, 0, 0);
		}, function(msg) {
			/* This is the "error" callback. */
			alert('Could not obtain a signature due to an error: ' + msg);
		}, {
			title : 'Please put your signature down below',
		});
	}

	$scope.uploadImage = function() {

		//Utils.showPleaseWait(pleaseWait);
		// Check whether image is attached or not
		var imgStatus = document.getElementById('image').style.display;

		if ($scope.isSignPad || imgStatus == "block") {

			for (var i = 0; i < $scope.records.length; i++) {
				if ($scope.records[i].field_name == 'sys_id') {
					var ticketSysId = $scope.records[i].field_value;
					break;
				}
			}
			var myDate = new Date();

			var year = myDate.getFullYear();

			var month = myDate.getMonth() + 1;
			if (month <= 9)
				month = '0' + month;

			var day = myDate.getDate();
			if (day <= 9)
				day = '0' + day;

			var hh = myDate.getHours() % 12 || 12;
			if (hh <= 9)
				hh = '0' + hh;

			var mm = myDate.getMinutes();
			if (mm <= 9)
				mm = '0' + mm;

			var ss = myDate.getSeconds();
			if (ss <= 9)
				ss = '0' + ss;

			var datetext = year + month + day + hh + mm + ss;

			var userLocation = $localstorage.getWithOutEncryption('USER-LOCATION');

			if (userLocation) {
				var n = userLocation.indexOf(",");
				var lat = userLocation.substring(0, n);
				//alert(res1);
				var lan = userLocation.substring(n + 1, userLocation.length);
			} else {
				userLocation = '';
			}

			// First Upload Signature image

			if ($scope.isSignPad) {
				//console.log(dataURL);
				var canvas = document.getElementById('signature');
				var signData = canvas.toDataURL();
				var pos = signData.indexOf(',');
				pos = pos + 1;
				$scope.signBase = signData.substr(pos);

				if (userLocation) {
					var attachmentName = 'SIGN-' + datetext + '-Lat' + lat + '-Lan' + lan;
				} else {
					var attachmentName = 'SIGN-' + datetext;
					//for Gallery
				}

				$http({
					method : 'POST',
					url : $rootScope.baseAppURL + '/api/inmpl/inm_mobile_application/inm_app_attachment_creator',
					data : {
						'tableName' : "u_avery_workreq_task",
						'recordSysId' : ticketSysId,
						'fileName' : attachmentName + '.' + 'png',
						'contentType' : "image/x-" + imgType,
						'payload' : $scope.signBase,
					},
					headers : {
						'Content-Type' : 'application/json',
						'Accept' : 'application/json',
					},
				}).success(function(record, status, headers, config) {
					if (status == 200) {
						//console.log(record && record.records && record.records[0] && record.records[0].__status && record.records[0].__status == 'success')
						//Utils.showAlert('Image has been uploaded successfully');

						//	$scope.fetchUpdatedRecord();

						//Utils.hidePleaseWait();
						//$scope.backToTicketsListing();
					}
				}).error(function(record, status, headers, config) {

					Utils.showAlert(unableToUpload);
					Utils.hidePleaseWait();
				});

			}

			if (imgStatus == "block") {

				var allowedExtension = ['jpeg', 'jpg', 'gif', 'png'];
				var fileExtension = document.getElementById('image').src.split('.').pop().toLowerCase();
				var imgPath = document.getElementById('image').src;
				var imgUrlPos = imgPath.lastIndexOf('/') + 1;
				var imgUrl = imgPath.lastIndexOf(".");
				//var userLocation = '';

				var cameraImg = document.getElementById('image');

				if (cameraImg.alt && userLocation && userLocation != '') {
					var attachmentName = cameraImg.alt + '-' + datetext + '-Lat' + lat + '-Lan' + lan;
				} else if (cameraImg.alt && userLocation == '') {
					var attachmentName = cameraImg.alt + '-' + datetext + '-Lat-NA-Lan-NA';
				} else {
					var attachmentName = imgPath.slice(imgUrlPos, imgUrl);
					//for Gallery
				}

				//	alert(fileExtension)
				var isValidFile = false;
				for (var index in allowedExtension) {
					if (fileExtension.search(allowedExtension[index]) > -1) {
						isValidFile = true;
						var imgType = allowedExtension[index]
						break;
					}

				}

				if (!isValidFile) {
					Utils.showAlert('Allowed Extensions are : *.' + allowedExtension.join(', *.') + '. Please remove the attachment OR try another image');
				} else {
					var imageURI = document.getElementById('image').src;
					toDataUrl(imageURI, function(base64Img) {
						var pos = base64Img.indexOf(',');
						pos = pos + 1;
						$scope.afterDot = base64Img.substr(pos);
						//console.log($scope.afterDot)

						$http({
							method : 'POST',
							url : $rootScope.baseAppURL + '/api/inmpl/inm_mobile_application/inm_app_attachment_creator',
							data : {
								'tableName' : "u_avery_workreq_task",
								'recordSysId' : ticketSysId,
								'fileName' : attachmentName + '.' + imgType,
								'contentType' : "image/x-" + imgType,
								'payload' : $scope.afterDot,
							},
							headers : {
								'Content-Type' : 'application/json',
								'Accept' : 'application/json',
							},
						}).success(function(record, status, headers, config) {
							if (status == 200) {
								$scope.isImageAttached = true;
								//console.log(record && record.records && record.records[0] && record.records[0].__status && record.records[0].__status == 'success')
								//Utils.showAlert('Image has been uploaded successfully');
								//Utils.hidePleaseWait();
								//$scope.backToTicketsListing();
								$scope.fetchUpdatedRecord();
							}
						}).error(function(record, status, headers, config) {
							Utils.showAlert(unableToUpload);
							Utils.hidePleaseWait();

						});

					});

				}

			} else {

			}
		} else {
			//Utils.hidePleaseWait();
			//$scope.backToTicketsListing();
			$scope.fetchUpdatedRecord();
		}

	}
	// Fetching Add spare part data
	try {
		Utils.showPleaseWait(pleaseWait);
		database.getAddSparePartData(function(result) {

			$scope.sparePartData = [];
			if (result && result.rows.length > 0) {
				try {

					for (var i = 0; i < result.rows.length; i++) {
						//console.log(angular.fromJson(result.rows.item(i).Data))

						var applicationAccess = angular.fromJson(result.rows.item(i).Data);
						//console.log(applicationAccess)
						for (var j = 0; j < applicationAccess.length; j++) {
							if (applicationAccess[j].field_name == 'r_workreq_task' && applicationAccess[j].field_value == $scope.ticketNumber)
								$scope.sparePartData.push(applicationAccess);
						}
					}
				} catch(e) {
				}
				//Utils.hidePleaseWait();
			}
			//console.log($scope.sparePartData)
			$scope.noTicketFlag = true;
			Utils.hidePleaseWait();
		});
	} catch(e) {
		Utils.hidePleaseWait();
	}

	$scope.addSparePartList = function(data) {

		for (var i = 0; i < $scope.records.length; i++) {
			if ($scope.records[i].field_Visible == 'true' && $scope.records[i].field_readonly == 'false') {
				var namee = $scope.records[i].field_name;
				$scope.partialform[namee] = $scope.records[i].field_value;
			}
		}

		$localstorage.setWithOutEncryption('PARTIAL_TICKET_DATA', JSON.stringify($scope.partialform));

		$localstorage.set('SELECTED_SPARE', angular.toJson(data));
		$state.go('eventmenu.addsparepartEdit');

	}

	$scope.addSparePart = function() {

		for (var i = 0; i < $scope.records.length; i++) {
			if ($scope.records[i].field_Visible == 'true' && $scope.records[i].field_readonly == 'false') {
				var namee = $scope.records[i].field_name;
				$scope.partialform[namee] = $scope.records[i].field_value;
			}
		}

		$localstorage.setWithOutEncryption('PARTIAL_TICKET_DATA', JSON.stringify($scope.partialform));

		$localstorage.setWithOutEncryption('Current-Ticket-Num', $scope.ticketSysId);

		$state.go('eventmenu.addsparepart');

	}

	$scope.choiceChange = function(field, fieldVal) {
		if (field == 'u_cost_included') {
			if (fieldVal && fieldVal.toLowerCase() == 'yes') {
				alert("Please make sure if 'Quote to Customer?' is checked then New Spare email will trigger to Sales team + Customer including price.")
			}
		}
	}

	$scope.fetchUpdatedRecord = function() {

		var promise = applicationServices.getVisitDetailsData();
		promise.then(function(payload) {
			if (payload) {
				//console.log(payload)
				if (payload && payload.status == 200 && payload.data && payload.data.result && payload.data.result.length > 0) {
					database.deleteCMDBData(function(data) {
						database.storeCMDBData(payload.data.result, function(data) {

							try {

								database.getVisitDetailsData(function(result) {
									//console.log(result)
									if (result && result.rows && result.rows.length > 0) {
										var applicationAccess = result.rows.item(0);

										$scope.updatedRecords = angular.fromJson(applicationAccess.Data);
										
										for (var i = 0; i < $scope.updatedRecords.length; i++) {
											for (var j = 0; j < $scope.updatedRecords[i].length; j++) {
												if ($scope.updatedRecords[i][j].field_name == 'number') {
													if ($scope.updatedRecords[i][j].field_value == $scope.ticketNumber)
														$localstorage.set('SELECTED_ACCOUNT', angular.toJson($scope.updatedRecords[i]));
													$scope.createUI();
													//$scope.records = $scope.updatedRecords[i];													
													Utils.hidePleaseWait();
												}
											}
										}

										$timeout(function() {// delay becuase ui takes some time to render
											$scope.noTicketFlag = true;
											Utils.hidePleaseWait();
										}, 500);
									} else {
										$scope.noTicketFlag = true;
										Utils.hidePleaseWait();
									}

								});
							} catch(e) {
								Utils.hidePleaseWait();
							}

						});
					});
				} else {

				}
			}
		}, function(errorPayload) {

		});

	}

	$scope.createUI();

})
