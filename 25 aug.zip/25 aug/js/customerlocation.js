angular.module('starter.controllers').controller('CustomerLocationCtrl', function($scope, $rootScope, $timeout, $state, $localstorage, $http, $window, database, Utils, applicationServices, $ionicScrollDelegate, NgMap) {

	$scope.$parent.$parent.$parent.app_page_title = 'Customer Location';
	$scope.$parent.$parent.$parent.showBackButton = 'showBackButton';
	$scope.$parent.$parent.$parent.showLogo = '';

	$localstorage.setWithOutEncryption('CUST-SYS-ID', '');

	$scope.mapSource = $localstorage.getWithOutEncryption('USER-LOCATION');
	$scope.mapDestination = $localstorage.getWithOutEncryption('CUST-LOCATION');

	//$scope.mapSource = '28.5870718,77.31311269999999';
	//$scope.mapDestination = '28.612912,77.22951';

})
