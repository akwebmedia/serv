angular.module('starter.controllers').controller('AddSparePartCtrl', function($scope, $rootScope, $timeout, $state, $localstorage, $http, $window, database, Utils, applicationServices, $ionicPopup, $parse, $ionicScrollDelegate) {

	$scope.$parent.$parent.$parent.app_page_title = 'Add Spare Part';
	$scope.$parent.$parent.$parent.showBackButton = 'showBackButton';
	$scope.$parent.$parent.$parent.showLogo = '';
	$scope.$parent.$parent.$parent.showTodayTaskIcon = false;
	$rootScope.setupHttpAuthHeader();

	$rootScope.setupHttpAuthHeader();
	$scope.show_section = {};

	var now = new Date();
	var tzoffset = (now).getTimezoneOffset() * 60000;
	//offset in milliseconds
	var todayDate = (new Date(Date.now() - tzoffset)).toISOString().slice(0, 10);
	var TicketSysId = $localstorage.getWithOutEncryption('Current-Ticket-Num');

	var userSysId = $localstorage.get('SN-USER-SYSID');

	// Accordion Display
	$scope.section_click = function(section, $event) {
		$scope[section] = !$scope[section];
		$ionicScrollDelegate.resize();
	};

	$scope.openTicketCheckPhone = function() {
		if ($('#openTicketCheckPhone').is(':hidden')) {
			return false;
		} else {
			return true;
		}
	};

	$scope.backToTicketsListing = function() {
		if ($scope.openTicketCheckPhone()) {
			//$state.go('eventmenu.myopenticketphone');
			$state.go('eventmenu.home');
		} else {
			$state.go('eventmenu.home');
		}
	};

	$scope.openInventory = function() {
		$scope.showInventory = true;
		$scope.inventoryData = [];
		try {
			Utils.showPleaseWait(pleaseWait);
			database.getTempSpareData(function(result) {

				$scope.totalRecords = [];
				if (result && result.rows.length > 0) {
					try {

						for (var i = 0; i < result.rows.length; i++) {
							//console.log(angular.fromJson(result.rows.item(i).Data))
							var applicationAccess = result.rows.item(i);
							$scope.inventoryData.push(angular.fromJson(applicationAccess.Data));
						}
					} catch(e) {
					}
					//Utils.hidePleaseWait();
				}

				//console.log($scope.inventoryData)
				//$scope.noTicketFlag = true;
				Utils.hidePleaseWait();
			});
		} catch(e) {
			Utils.hidePleaseWait();
		}
	}

	$scope.selectedSpareData = function(data) {

		for (var i = 0; i < data.length; i++) {
			if (data[i].field_name == 'r_part_information') {
				$scope.location = data[i].field_value;
			} else if (data[i].field_name == 'u_available_qty') {
				$scope.availableQty = data[i].field_value;
			} else if (data[i].field_name == 'sys_id') {
				$scope.sysid = data[i].field_value;
			}
		}

		$scope.showInventory = false;

		$ionicScrollDelegate.scrollTop();

	}

	$scope.SubmitFormData = function(avilQty, loanQty, desc) {
		$scope.formData = {};
		if (loanQty) {
			if (loanQty > avilQty || loanQty == 0) {
				Utils.showAlert("Please enter the correct Loan Quantity");
			} else {
				$scope.formData.u_workreq_task = TicketSysId;
				$scope.formData.u_loan_taken_by = userSysId;
				$scope.formData.u_location_inventory = $scope.sysid;
				$scope.formData.u_spare_status = "Loan";
				$scope.formData.u_loan_qty = loanQty;
				$scope.formData.u_description = desc;
				$scope.formData.u_temp_spare_installation_date = todayDate;

				//console.log($scope.formData);

				$http({
					method : 'POST',
					url : $rootScope.baseAppURL + '/api/now/table/u_avery_temp_asset_usage',
					data : $scope.formData,
					headers : {
						'Content-Type' : 'application/json',
						'Accept' : 'application/json',
					},
				}).success(function(data, status, headers, config) {
					if (status == 200 || status == 201) {
						$state.go('eventmenu.home');
					}

				}).error(function(data, status, headers, config) {
					//Utils.showAlert(unableToUpload);
					//Utils.hidePleaseWait();
				});
			}
		} else {
			Utils.showAlert("Please enter the Loan Quantity");
		}

	}
})