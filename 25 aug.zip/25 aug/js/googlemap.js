angular.module('starter.controllers').controller('GoogleMapCtrl', function($scope, $rootScope, $timeout, $state, $localstorage, $http, $window, database, Utils, applicationServices, $ionicScrollDelegate, NgMap) {

	$scope.$parent.$parent.$parent.app_page_title = 'Customer Location';
	$scope.$parent.$parent.$parent.showBackButton = 'showBackButton';
	$scope.$parent.$parent.$parent.showLogo = '';

	$localstorage.setWithOutEncryption('CUST-SYS-ID', '');

	var currentTicket = $localstorage.getWithOutEncryption('Current-Ticket');

	Utils.showPleaseWait(pleaseWait);
	$timeout(function() {
		database.getVisitDetailsData(function(result) {

			var applicationAccess = result.rows.item(0);

			$scope.totalRecords = angular.fromJson(applicationAccess.Data);
			console.log($scope.totalRecords)
		});

	}, 1000);

	$timeout(function() {

		$scope.tempDatan = [];
		$scope.tempData = {};
		$scope.tempData['icon'] = '';

		if ($scope.totalRecords && $scope.totalRecords.length > 0) {

			for ( i = 0; i < $scope.totalRecords.length; i++) {
				for ( j = 0; j < $scope.totalRecords[i].length; j++) {
					var pos = [];

					//console.log($scope.totalRecords[i][j].field_name);
					//console.log($scope.totalRecords[i][j].field_value);
					if ($scope.totalRecords[i][j].field_name == 'u_customer_latitude') {

						$scope.tempData['Lat'] = $scope.totalRecords[i][j].field_value;
					} else if ($scope.totalRecords[i][j].field_name == 'u_customer_longitude') {

						$scope.tempData['Long'] = $scope.totalRecords[i][j].field_value;
					} else if ($scope.totalRecords[i][j].field_name == 'number') {
						$scope.tempData['Tnumber'] = $scope.totalRecords[i][j].field_value;
						$scope.tempData['id'] = $scope.totalRecords[i][j].field_value;

						if ($scope.totalRecords[i][j].field_value == currentTicket) {
							$scope.tempData['icon'] = 'http://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|311b92';
						} else {
							$scope.tempData['icon'] = '';
						}

						//$scope.tempData.push('Number',$scope.totalRecords[i][j].field_value)
					} else if ($scope.totalRecords[i][j].field_name == 'u_company') {
						$scope.tempData['Customer'] = $scope.totalRecords[i][j].field_value;

					} else if ($scope.totalRecords[i][j].field_name == 'r_activity_type') {
						$scope.tempData['Activity'] = $scope.totalRecords[i][j].field_value;

					} else if ($scope.totalRecords[i][j].field_name == 'u_status') {
						$scope.tempData['Status'] = $scope.totalRecords[i][j].field_value;

					} else {
						//break;
					}

				}

				pos.push(Number($scope.tempData.Lat));
				pos.push(Number($scope.tempData.Long));

				$scope.tempDatan.push({
					'id' : $scope.tempData.Tnumber,
					'name' : $scope.tempData.Tnumber,
					'customer' : $scope.tempData.Customer,
					'activity' : $scope.tempData.Activity,
					'status' : $scope.tempData.Status,
					'position' : pos,
					'icon' : $scope.tempData.icon
				});
				//$scope.tempDataaa.push($scope.tempData);

				//console.log($scope.tempDatan);
			}
			//console.log($scope.tempDataaa);

		}

	}, 1500);

	var userLocation = $localstorage.getWithOutEncryption('USER-LOCATION');
	if (userLocation) {
		$scope.currentPos = userLocation;
		//userLocation;
		//console.log($scope.currentPos )
	}

	//var pos = ['asd','asd'];
	//var person = {firstName:"John", lastName:"Doe", pos};
	//console.log(person)

	//$scope.mapSource = '28.5870718,77.31311269999999';
	//$scope.mapDestination = '28.612912,77.22951';
	var vm = this;
	$timeout(function() {
		Utils.hidePleaseWait();

		NgMap.getMap().then(function(map) {
			//console.log('map', map);
			vm.map = map;
		});

		vm.clicked = function() {
			//alert('Clicked a link inside infoWindow');
		};
		console.log($scope.tempDatan)
		vm.shops = $scope.tempDatan;

		/*vm.shops = [
		 {id:'foo', name: 'FOO SHOP', position:[41,-87]},
		 {id:'bar', name: 'BAR SHOP', position:[42,-86]}
		 ];*/
		console.log(vm.shops)

		//[  {id:'foo', name: 'FOO SHOP', position:[41,-87]},    {id:'bar', name: 'BAR SHOP', position:[42,-86]}  ];
		vm.shop = vm.shops[0];
		console.log(vm.shop)

		vm.showDetail = function(e, shop) {
			vm.shop = shop;
			vm.map.showInfoWindow('foo-iw', shop.id);
		};

		vm.hideDetail = function() {
			vm.map.hideInfoWindow('foo-iw');
		};

	}, 2000);
	// JavaScript Document

})