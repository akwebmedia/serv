angular.module('starter.controllers').controller('dashBoardCtrl', function($scope, $rootScope, $timeout, $state, $localstorage, $http, $window, database, Utils, applicationServices, $ionicScrollDelegate) {
	$scope.$parent.$parent.$parent.showTodayTaskIcon = true;
	$scope.$parent.$parent.$parent.app_page_title = 'Dashboard';
	$scope.$parent.$parent.$parent.showBackButton = 'showBackButton';
	$scope.$parent.$parent.$parent.showLogo = '';
	$scope.$parent.$parent.$parent.showTodayTaskIcon = false;
	$scope.changePasscode = false;
	$rootScope.setupHttpAuthHeader();
		var now = new Date();
	var tzoffset = (now).getTimezoneOffset() * 60000;
	var todayDate = (new Date(Date.now() - tzoffset)).toISOString().slice(0, 10);
	var currentMonth = todayDate.slice(5, 7);
	console.log(currentMonth);

	try {
		database.getVisitDetailsData(function(result) {
			$scope.installationCount = 0;
			$scope.visitDetailsCount = 0;
			$scope.evvCount = 0;
			$scope.amcCount = 0;
			$scope.monthlyCount = 0;
			if (result && result.rows && result.rows.length > 0) {
				var applicationAccess = result.rows.item(0);
				$scope.totalRecords = angular.fromJson(applicationAccess.Data);
				$scope.visitDetailsCount = $scope.totalRecords.length;

				for (var i = 0; i < $scope.totalRecords.length; i++) {
					for ( j = 0; j < $scope.totalRecords[i].length; j++) {
						if ($scope.totalRecords[i][j].field_name == 'r_activity_type') {
							if ($scope.totalRecords[i][j].field_refID == 'ddc0de124fd3ba00def782818110c717' || $scope.totalRecords[i][j].field_refID == '87319a124fd3ba00def782818110c7db' || $scope.totalRecords[i][j].field_refID == '6a61d2524fd3ba00def782818110c7c8' || $scope.totalRecords[i][j].field_refID == 'ba7192524fd3ba00def782818110c779' || $scope.totalRecords[i][j].field_refID == '7681d2524fd3ba00def782818110c735' || $scope.totalRecords[i][j].field_refID == '2a91d6124fd3ba00def782818110c77c' || $scope.totalRecords[i][j].field_refID == '632331f94f5c8700def782818110c7ef') {
								$scope.installationCount = $scope.installationCount + 1;
							} else if ($scope.totalRecords[i][j].field_refID == '0fe19e124fd3ba00def782818110c767' || $scope.totalRecords[i][j].field_refID == '6f345c5fbb188b00a7331272dbdb750d' || $scope.totalRecords[i][j].field_refID == '1214509fbb188b00a7331272dbdb7575') {
								$scope.evvCount = $scope.evvCount + 1;
							} else if ($scope.totalRecords[i][j].field_refID == '42d1d6524fd3ba00def782818110c723' || $scope.totalRecords[i][j].field_refID == '68b156524fd3ba00def782818110c700') {
								$scope.amcCount = $scope.amcCount + 1;
							}
						} else if ($scope.totalRecords[i][j].field_name == 'u_acceptance_date') {							
								if ($scope.totalRecords[i][j].field_value.slice(5, 7) == currentMonth) {
									$scope.monthlyCount = $scope.monthlyCount + 1;					
						}
						}

					}
					if (i == ($scope.totalRecords.length) - 1) {
						Utils.hidePleaseWait();
					}
				}
			}

		});
	} catch(e) {

	}

});
